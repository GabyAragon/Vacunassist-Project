from app.models.notificacion import Notificacion
from app.models.solicitud import Solicitud
from app.models.user import User
from app.models.usuario import Usuario
from app.models.turno import Turno
import datetime
from app.models.misvacunas import Misvacunas
from datetime import date
from app.db import db
import random

from app.models.vacunatorio import Vacunatorio

def authenticated(session):
    return session.get("user")

def rolpersona(user_email):
    query = Usuario.query.filter(Usuario.email == user_email).first()
    if query.rol == "persona":
        return True
    else: return False    

def rolvacunador(user_email):
    query = Usuario.query.filter(Usuario.email == user_email).first()
    if query.rol == "vacunador":
        return True
    else: return False

def roladmin(user_email):
    query = Usuario.query.filter(Usuario.email == user_email).first()
    if query.rol == "admin":
        return True
    else: return False   

def nya(user_email):
    query = Usuario.query.filter(Usuario.email == user_email).first()
    mynya = query.nombre+" "+query.apellido
    
    return mynya   

def check(user_email, permission):
    query = User.query.filter(User.email == user_email).first()
    user_id = query.id
    return User.has_permission(user_id,permission)


# agregado para ver si tiene un turno para vacunacion de covid, si no la tiene ya aplicada y es mayor de edad
def puedePedirCovid(user_email):
    queryTurno = Turno.query.filter(Turno.email == user_email).filter(Turno.tipovacuna == "Covid-19").first()  #pregunta si tiene turno para la vacuna
    queryVacunas = Misvacunas.query.filter(Misvacunas.email == user_email).filter(Misvacunas.tipovacuna == "Covid-19").first()  #pregunta si tiene la vacuna ya aplicada
    querySolicitud = Solicitud.query.filter(Solicitud.email == user_email).filter(Solicitud.tipovacuna == "Covid-19").first()
    if not queryTurno:
        if not queryVacunas:
            if not querySolicitud:
                myuser = Usuario.query.filter(Usuario.email == user_email).filter(Usuario.fecnac).first()
                ahora = datetime.datetime.utcnow()
                dias = ((ahora.date())-myuser.fecnac).days
                if dias > 6570:  #verifica que sea mayor a 18
                    return True
    return False  

# agregado para ver si tiene un turno para vacunacion antigripal y si no la tiene ya aplicada
def puedePedirGripe(user_email):
    queryTurno = Turno.query.filter(Turno.email == user_email).filter(Turno.tipovacuna == "Antigripal").first()  #pregunta si tiene turno para la vacuna
    queryVacunas = Misvacunas.query.filter(Misvacunas.email == user_email).filter(Misvacunas.tipovacuna == "Antigripal").first()  #pregunta si tiene la vacuna ya aplicada
    if not queryTurno:
        if not queryVacunas :
            return True
    return False   

# agregado para ver si tiene un turno para vacunacion de fiebre, si no la tiene ya aplicada y que sea menor de 60
def puedePedirFiebre(user_email):
    queryTurno = Turno.query.filter(Turno.email == user_email).filter(Turno.tipovacuna == "Fiebre amarilla").first()  #pregunta si tiene turno para la vacuna
    queryVacunas = Misvacunas.query.filter(Misvacunas.email == user_email).filter(Misvacunas.tipovacuna == "Fiebre amarilla").first()  #pregunta si tiene la vacuna ya aplicada
    querySolicitud = Solicitud.query.filter(Solicitud.email == user_email).filter(Solicitud.tipovacuna == "Fiebre amarilla").first()
    if not queryTurno:
        if not queryVacunas:
            if not querySolicitud:
                myuser = Usuario.query.filter(Usuario.email == user_email).filter(Usuario.fecnac).first()
                ahora = datetime.datetime.utcnow()
                dias = ((ahora.date())-myuser.fecnac).days
                if dias < 21900: #verifica que sea menor a 60 
                    return True
    return False

def turnosdeldia(myuser):
    hoy = date.today()
    myuser = Usuario.query.filter(Usuario.email == myuser).first()
    
    turnos = Turno.query.join(Usuario).where(Turno.idpersona == Usuario.id).filter(
    Turno.fecha_turno == hoy
    ).filter(Turno.zona == myuser.zona).all()   
    
    return turnos

#La pesrona cumple 60 años y puede reclamar un turno más actual de covid
def reclamarCovid(user_email):
    queryTurno = Turno.query.filter(Turno.email == user_email).filter(Turno.tipovacuna == "Covid-19").first()  #pregunta si tiene turno para la vacuna
    queryVacunas = Misvacunas.query.filter(Misvacunas.email == user_email).filter(Misvacunas.tipovacuna == "Covid-19").first()  #pregunta si tiene la vacuna ya aplicada
    querySolicitud = Solicitud.query.filter(Solicitud.email == user_email).filter(Solicitud.tipovacuna == "Covid-19").first()
    myuser = Usuario.query.filter(Usuario.email == user_email).filter(Usuario.fecnac).first()
    ahora = datetime.datetime.utcnow()
    dias = ((ahora.date())-myuser.fecnac).days
    if dias > 21900: #verifica que sea mayor a 60
        if not queryVacunas:    
            if querySolicitud:
                return True
            else:
                if queryTurno:
                    misdias = (queryTurno.fecha_turno-(ahora.date())).days 
                    if misdias > 7: 
                        return True
    return False 

# La persona cumple 60 años y puede reclamar un turno más actual de antigripal
def reclamarGripe(user_email):
    queryTurno = Turno.query.filter(Turno.email == user_email).filter(Turno.tipovacuna == "Antigripal").first()  #pregunta si tiene turno para la vacuna
    queryVacunas = Misvacunas.query.filter(Misvacunas.email == user_email).filter(Misvacunas.tipovacuna == "Antigripal").first()  #pregunta si tiene la vacuna ya aplicada
    myuser = Usuario.query.filter(Usuario.email == user_email).filter(Usuario.fecnac).first()
    ahora = datetime.datetime.utcnow()
    dias = ((ahora.date())-myuser.fecnac).days
    if dias > 21900: #verifica que sea mayor a 60
        if not queryVacunas:
            if queryTurno:
                    misdias = (queryTurno.fecha_turno-(ahora.date())).days 
                    if misdias > 90: 
                        return True
                
            
    return False    

def tengonotificaciones(user_email):
    misnotis = Notificacion.query.filter(Notificacion.email == user_email).all()
    if not misnotis:
        return False
    else:
        return True

def vacunatorio1():
    vac = Vacunatorio.query.filter(Vacunatorio.id == 1).first()
    return vac.nombre

def vacunatorio2():
    vac = Vacunatorio.query.filter(Vacunatorio.id == 2).first()
    return vac.nombre

def solicitudes(myuser):
    myuser = Usuario.query.filter(Usuario.email == myuser).first()
    soli = Solicitud.query.all() 
    return soli

def vacunatorio3():
    vac = Vacunatorio.query.filter(Vacunatorio.id == 3).first()
    return vac.nombre