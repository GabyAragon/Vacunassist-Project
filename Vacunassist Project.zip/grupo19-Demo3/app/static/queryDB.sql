-- ADMIN
###############
INSERT INTO `usuario` (`id`,`nombre`, `apellido`, `dni`, `fecnac`, `zona`, `email`, `password`, `codigo`, `rol`, `log`) VALUES ('1', 'Lautaro', 'admin', '32008659', '2022-05-28', '1', 'admin@admin.com', '123456', '1234', 'admin', '1');
INSERT INTO `usuario` (`id`,`nombre`, `apellido`, `dni`, `fecnac`, `zona`, `email`, `password`, `codigo`, `rol`, `log`) VALUES ('2', 'Agustina', 'admin', '32008660', '2022-05-28', '1', 'admin2@admin.com', '123456', '1234', 'admin', '1');

-- VACUNADOR
###############
INSERT INTO `usuario` (`id`,`nombre`, `apellido`, `dni`, `fecnac`, `zona`, `email`, `password`, `codigo`, `rol`, `log`) VALUES ('8', 'Gabriela', 'Sabatini', '32008661', '2022-05-28', '1', 'vacunador@vacunador.com', '123456', '1234', 'vacunador', '1');
INSERT INTO `usuario` (`id`,`nombre`, `apellido`, `dni`, `fecnac`, `zona`, `email`, `password`, `codigo`, `rol`, `log`) VALUES ('11', 'Lionel', 'Messi', '38108642', '2022-05-28', '2', 'vacunador1@vacunador.com', '123456', '1234', 'vacunador', '1');
INSERT INTO `usuario` (`id`,`nombre`, `apellido`, `dni`, `fecnac`, `zona`, `email`, `password`, `codigo`, `rol`, `log`) VALUES ('12', 'Angel', 'Di Maria', '43008145', '2022-05-28', '3', 'vacunador2@vacunador.com', '123456', '1234', 'vacunador', '1');
INSERT INTO `usuario` (`id`,`nombre`, `apellido`, `dni`, `fecnac`, `zona`, `email`, `password`, `codigo`, `rol`, `log`) VALUES ('13', 'Luciana', 'Aymar', '45008687', '2022-05-28', '1', 'vacunador3@vacunador.com', '123456', '1234', 'vacunador', '1');
INSERT INTO `usuario` (`id`,`nombre`, `apellido`, `dni`, `fecnac`, `zona`, `email`, `password`, `codigo`, `rol`, `log`) VALUES ('14', 'Lautaro', 'Martinez', '24008999', '2022-05-28', '2', 'vacunador4@vacunador.com', '123456', '1234', 'vacunador', '1');

-- PERSONAS
###############
INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `dni`, `fecnac`, `telefono`, `zona`, `email`, `password`, `codigo`, `rol`, `riesgo`, `log`) VALUES ('3', 'Juan', 'Perez', '44555666', '2022-05-30', '123456789', '1', 'juan@perez.com', '123456', '1234', 'persona', '0', '1');
INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `dni`, `fecnac`, `telefono`, `zona`, `email`, `password`, `codigo`, `rol`, `riesgo`, `log`) VALUES ('4', 'Maria', 'Lopez', '33444555', '2022-05-30', '123456789', '1', 'maria@lopez.com', '123456', '1234', 'persona', '0', '1');
INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `dni`, `fecnac`, `telefono`, `zona`, `email`, `password`, `codigo`, `rol`, `riesgo`, `log`) VALUES ('5', 'Carlos', 'Rodriguez', '22333444', '2022-05-30', '123456789', '1', 'carlos@rodriguez.com', '123456', '1234', 'persona', '0', '1');
INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `dni`, `fecnac`, `telefono`, `zona`, `email`, `password`, `codigo`, `rol`, `riesgo`, `log`) VALUES ('6', 'Carmen', 'Garcia', '11222333', '2022-05-30', '123456789', '1', 'carmen@garcia.com', '123456', '1234', 'persona', '0', '1');
INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `dni`, `fecnac`, `telefono`, `zona`, `email`, `password`, `codigo`, `rol`, `riesgo`, `log`) VALUES ('7', 'Roberto', 'Halfonso', '55666777', '2022-05-30', '123456789', '1', 'roberto@halfonso.com', '123456', '1234', 'persona', '0', '1');
INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `dni`, `fecnac`, `telefono`, `zona`, `email`, `password`, `codigo`, `rol`, `riesgo`, `log`) VALUES ('9', 'Notengo18', 'Demo2', '65656565', '2012-05-30', '123456789', '1', 'notengo18@demo2.com', '123456', '1234', 'persona', '0', '1');
INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `dni`, `fecnac`, `telefono`, `zona`, `email`, `password`, `codigo`, `rol`, `riesgo`, `log`) VALUES ('10', 'Tengo60', 'Demo2', '12121212', '1940-05-30', '123456789', '1', 'tengo60@demo2.com', '123456', '1234', 'persona', '0', '1');

-- TURNOS
###############
INSERT INTO `turnos` (`id`, `email`, `tipovacuna`, `fecha_turno`, `hora`, `zona`,`idpersona`) VALUES ('1', 'juan@perez.com', 'Antigripal', '2022-06-13', '15', '1','3');
INSERT INTO `turnos` (`id`, `email`, `tipovacuna`, `fecha_turno`, `hora`, `zona`,`idpersona`) VALUES ('2', 'maria@lopez.com', 'Antigripal', '2022-06-13', '9', '1','4');
INSERT INTO `turnos` (`id`, `email`, `tipovacuna`, `fecha_turno`, `hora`, `zona`,`idpersona`) VALUES ('3', 'carlos@rodriguez.com', 'Covid-19', '2022-06-13', '12', '1','5');
INSERT INTO `turnos` (`id`, `email`, `tipovacuna`, `fecha_turno`, `hora`, `zona`,`idpersona`) VALUES ('4', 'carmen@garcia.com', 'Covid-19', '2022-06-13', '10', '1','6');
INSERT INTO `turnos` (`id`, `email`, `tipovacuna`, `fecha_turno`, `hora`, `zona`,`idpersona`) VALUES ('5', 'roberto@halfonso.com', 'Fiebre amarilla', '2022-06-13', '14', '1','7');

-- SOLICITUDES
################
INSERT INTO `solicitudes` (`id`, `email`, `tipovacuna`) VALUES ('1','tengo60@demo2.com', 'Fiebre amarilla');
INSERT INTO `solicitudes` (`id`, `email`, `tipovacuna`) VALUES ('2', 'juan@perez.com', 'Covid-19');
INSERT INTO `solicitudes` (`id`, `email`, `tipovacuna`) VALUES ('3', 'maria@lopez.com', 'Fiebre amarilla');
INSERT INTO `solicitudes` (`id`, `email`, `tipovacuna`) VALUES ('4','tengo60@demo2.com', 'Covid-19');

-- VACUNATORIOS
################
INSERT INTO `vacunatorio` (`id`,`nombre`) VALUES ('1','Zona plaza Moreno');
INSERT INTO `vacunatorio` (`id`,`nombre`) VALUES ('2','Zona terminal');
INSERT INTO `vacunatorio` (`id`,`nombre`) VALUES ('3','Zona cementerio');