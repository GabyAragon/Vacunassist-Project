import { Map } from '..\js\mapa.js'

window.onload = () =>{
    const map = new Map ({
        selector: 'mapid',
        addSearch: true
    });
    const button = document.getElementById("btn-coordenadas");
    
}
