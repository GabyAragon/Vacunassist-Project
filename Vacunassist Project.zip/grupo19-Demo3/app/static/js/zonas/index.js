import { Map } from '../../js/mapSingleMarker.js'

window.onload = () =>{
    const map = new Map ({
        selector: 'mapid',
        addSearch: true
    });
    const button = document.getElementById("btn-coordenadas");
    
}