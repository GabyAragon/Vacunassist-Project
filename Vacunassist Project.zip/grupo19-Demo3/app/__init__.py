from os import path, environ
from flask import Flask, Blueprint
from flask_session import Session
from config import config
from app import db
from app.resources import user
from app.resources import auth
from app.resources import configModule
from app.helpers import handler
from app.helpers import auth as helper_auth
import logging
from app.resources import home
from app.resources import usuario
from app.resources import admin
from app.resources import vacunador



logging.basicConfig()
logging.getLogger("sqlalchemy.engine").setLevel(logging.INFO)


def create_app(environment="development"):
    # Configuración inicial de la app
    app = Flask(__name__)

    # Carga de la configuración
    env = environ.get("FLASK_ENV", environment)
    app.config.from_object(config[env])

    # Upload folder
    UPLOAD_FOLDER = 'static/files'
    app.config['UPLOAD_FOLDER'] =  UPLOAD_FOLDER

    # Server Side session
    app.config["SESSION_TYPE"] = "filesystem"
    Session(app)

    # Configure db
    db.init_app(app)

    # Funciones que se exportan al contexto de Jinja2
    app.jinja_env.globals.update(is_authenticated=helper_auth.authenticated)
    app.jinja_env.globals.update(has_permission=helper_auth.check)
    app.jinja_env.globals.update(rolpersona=helper_auth.rolpersona)
    app.jinja_env.globals.update(rolvacunador=helper_auth.rolvacunador)
    app.jinja_env.globals.update(roladmin=helper_auth.roladmin)
    app.jinja_env.globals.update(nya=helper_auth.nya)
    app.jinja_env.globals.update(puedePedirCovid=helper_auth.puedePedirCovid)
    app.jinja_env.globals.update(puedePedirGripe=helper_auth.puedePedirGripe)
    app.jinja_env.globals.update(puedePedirFiebre=helper_auth.puedePedirFiebre)
    app.jinja_env.globals.update(turnosdeldia=helper_auth.turnosdeldia)
    app.jinja_env.globals.update(solicitudes=helper_auth.solicitudes)
    app.jinja_env.globals.update(reclamarCovid=helper_auth.reclamarCovid)
    app.jinja_env.globals.update(reclamarGripe=helper_auth.reclamarGripe)
    app.jinja_env.globals.update(tengonotificaciones=helper_auth.tengonotificaciones)
    app.jinja_env.globals.update(vacunatorio1=helper_auth.vacunatorio1)
    app.jinja_env.globals.update(vacunatorio2=helper_auth.vacunatorio2)
    app.jinja_env.globals.update(vacunatorio3=helper_auth.vacunatorio3)              

    #Persona pública
    # Autenticación
                    #navegador url   /   indice    /    redirije (del resources)
    app.add_url_rule("/iniciar_sesion", "auth_login", auth.login)
    app.add_url_rule("/cerrar_sesion", "auth_logout", auth.logout)
    app.add_url_rule("/datosPersonales", "auth_signup", auth.signup)
    app.add_url_rule(
        "/autenticacion", "auth_authenticate", auth.authenticate, methods=["POST"]
    )

    # Rutas usuarios Vacunassit
    app.add_url_rule("/registrarse", "usuario_registrarse", usuario.create, methods=["POST"])
    app.add_url_rule("/modificarPerfil", "modificarperfil", usuario.edit)
    app.add_url_rule("/modificarDatos", "modificardatos", usuario.update, methods=["POST"])
    app.add_url_rule("/modificarPassword", "modificarpass", usuario.editpass)
    app.add_url_rule("/updatePassword", "updatepass", usuario.updatepass, methods=["POST"])
    app.add_url_rule("/registrarMisVacunas", "registrarmisvacunas", usuario.registrarmisvacunas, methods=["POST"])
    app.add_url_rule("/misVacunas", "misvacunas", usuario.misvacunas)
    app.add_url_rule("/misTurnos", "misturnos", usuario.misturnos)
    app.add_url_rule("/SolicitarTurnoCovid", "darturnocovid", usuario.solicitarturnocovid)
    app.add_url_rule("/SolicitarTurnoGripe", "darturnogripe", usuario.solicitarturnogripe)
    app.add_url_rule("/SolicitarTurnoFiebre", "darturnofiebre", usuario.solicitarturnofiebre)
    app.add_url_rule("/ReclamarTurnoCovid", "reclamarCovid", usuario.reclamarCovid)
    app.add_url_rule("/ReclamarTurnoAntigripal", "reclamarGripe", usuario.reclamarGripe)
    app.add_url_rule("/MisNotificaciones", "misnotificaciones", usuario.misnotificaciones)
    app.add_url_rule("/Leido/<int:noti_id>", "leido", usuario.leido)
          

    # Rutas vacunador Vacunassit 
    app.add_url_rule("/turnosDelDia", "turnosdeldias", vacunador.turnosdeldias)
    app.add_url_rule("/atendido/<int:turno_id>", "atendido", vacunador.atendido, methods=["GET"])
    app.add_url_rule("/atencion_confirmada/<int:turno_id>", "atencion_confirmada", vacunador.atencionconfirmada, methods=["GET"])
    app.add_url_rule("/confirmarAusentes", "confirmarausentes", vacunador.confirmarausentes)
    app.add_url_rule("/registrarausentes", "registrarausentes", vacunador.registrarausentes)
    app.add_url_rule("/misDatosPersonales", "new_persona", vacunador.newpersona)
    app.add_url_rule("/nuevaPersona", "nueva_persona", vacunador.nuevapersona, methods=["POST"])
    app.add_url_rule("/nuevaPersonaMisVacunas", "nuevapersonamisvacunas", vacunador.nuevapersonamisvacunas, methods=["POST"])
    app.add_url_rule("/nuevaVacunacion", "new_vacunacion", vacunador.newvacunacion)
    app.add_url_rule("/confirmarVacunacion", "confirmar_vacunacion", vacunador.confirmarvacunacion, methods=["POST"])
    app.add_url_rule("/aceptarVacunacion", "aceptar_vacunacion", vacunador.aceptarvacunacion, methods=["POST"])
      

    # Rutas admin Vacunassit
    app.add_url_rule("/registrarVacunador", "new_vacunador", admin.newvacunador)
    app.add_url_rule("/crearVacunador", "vacunador_registrarse", admin.createvacunador, methods=["POST"])
    app.add_url_rule("/botones", "botones", admin.botones)
    app.add_url_rule("/cumpli18", "cumpli18", admin.cumpli18)
    app.add_url_rule("/cumpli60", "cumpli60", admin.cumpli60)
    app.add_url_rule("/verVacunadores", "ver_vacunadores", admin.vervacunadores)
    app.add_url_rule("/vacunasAplicadas", "vacunas_aplicadas", admin.vacunasaplicadas)
    app.add_url_rule("/personasRegistradas", "personas_registradas", admin.personasregistradas)
    app.add_url_rule("/solicitudesPendientes", "solicitudes_pendientes", admin.solicitudespendientes)
    app.add_url_rule("/darTurno/<int:solicitud_id>", "dar_turno", admin.darturno, methods=["GET"])
    app.add_url_rule("/registrarTurno", "registrar_turno", admin.registrarturno, methods=["POST"])
    app.add_url_rule("/modificarNombreVacunatorio", "modificar_nombre_vacunatorio", admin.modificarnombrevacunatorio)
    app.add_url_rule("/editarVacunatorio/<int:vacu_id>", "editar_vacunatorio", admin.editarvacunatorio, methods=["GET"])
    app.add_url_rule("/updateVacunatorio", "updatevacunatorio", admin.updatevacunatorio, methods=["POST"])
    app.add_url_rule("/searchpersonas", "searchpersonas", admin.searchpersonas, methods=["POST"])
    app.add_url_rule("/searchvacunas", "searchvacunas", admin.searchvacunas, methods=["POST"]) 
    app.add_url_rule("/searchvacunadores", "searchvacunadores", admin.searchvacunadores, methods=["POST"])
    
    
    # Rutas de Usuarios
    app.add_url_rule("/usuarios", "user_index", user.index)
    app.add_url_rule("/usuarios/nuevo", "user_new", user.new)
    app.add_url_rule("/usuarios", "user_create", user.create, methods=["POST"])
    app.add_url_rule("/usuarios/editar", "user_edit", user.edit)
    app.add_url_rule("/usuarios/actualizar", "user_update", user.update, methods=["POST"])
    app.add_url_rule("/usuarios/eliminar/<int:user_id>", "user_eliminar", user.eliminar, methods=["GET"])
    app.add_url_rule("/usuarios/delete/<int:user_id>", "user_delete", user.delete, methods=["GET"])
    app.add_url_rule("/usuarios/activos", "user_activos", user.activos)
    app.add_url_rule("/usuarios/bloquear/<int:user_id>", "user_bloquear", user.bloquear, methods=["GET"])
    app.add_url_rule("/usuarios/bloqueados", "user_bloqueados", user.bloqueados)
    app.add_url_rule("/usuarios/activar/<int:user_id>", "user_activar", user.activar, methods=["GET"])
    app.add_url_rule("/usuarios/searchbyusername", "user_searchbyusername", user.searchbyusername, methods=["POST"])

    # Rutas del Admin
    app.add_url_rule("/admin/config_module","config_module_index", configModule.index)
    app.add_url_rule("/admin/config_module/config_update","config_module_update", configModule.update, methods=["POST"])

   
    # Ruta del home
    app.add_url_rule("/", "home", home.index)

    # Rutas de API-REST (usando Blueprints)
    api = Blueprint("api", __name__, url_prefix="/api")
        
    # Handlers
    app.register_error_handler(404, handler.not_found_error)
    app.register_error_handler(401, handler.unauthorized_error)
    app.register_error_handler(500, handler.internal_server_error)
    app.register_error_handler(400, handler.bad_resquest)

    # Retornar la instancia de app configurada
    return app
