from re import U
from xmlrpc.client import DateTime
from flask import redirect, render_template, request, url_for, session, abort, flash
from sqlalchemy.sql.elements import Null
from app.models.user import User
from app.helpers.auth import authenticated
from app.db import db
from app.models.configModule import ConfigModule
from sqlalchemy import update
import bcrypt
from app.models.usuario import Usuario
from app.models.misvacunas import Misvacunas
from app.models.turno import Turno
from app.models.solicitud import Solicitud
import random
import datetime
from datetime import date
from sqlalchemy import Date, cast

def turnosdeldias():
    if not authenticated(session):
        abort(401)
    
    hoy = date.today()
    myuser = Usuario.query.filter(Usuario.email == session["user"]).first()
    
    turnos = Turno.query.join(Usuario).where(Turno.idpersona == Usuario.id).filter(
    Turno.fecha_turno == hoy
    ).filter(Turno.zona == myuser.zona).all()   
    
        

    return render_template("vacunador/turnostoday.html", turnos = turnos)

def atendido(turno_id):
    if not authenticated(session):
        abort(401)
    
    turno = Turno.query.join(Usuario).where(Turno.idpersona == Usuario.id).filter(
        Turno.id == turno_id
    ).first()
    return render_template("vacunador/showatendido.html",turno = turno)

def atencionconfirmada(turno_id):
    if not authenticated(session):
        abort(401)

    miturno = Turno.query.filter(Turno.id == turno_id).first()
    db.session.delete(miturno)
    
    hoy = date.today()
    newvacuna = Misvacunas(miturno.email,miturno.tipovacuna,hoy)
    newvacuna.idpersona = miturno.idpersona
    newvacuna.vacunador = session["user"]
    newvacuna.zona = miturno.zona
    db.session.add(newvacuna)

    db.session.commit()
    flash('Vacunación registrada')
    return redirect(url_for("turnosdeldias"))
 


def confirmarausentes():
    if not authenticated(session):
        abort(401)
    
    hoy = date.today()
    myuser = Usuario.query.filter(Usuario.email == session["user"]).first()
    
    turnos = Turno.query.join(Usuario).where(Turno.idpersona == Usuario.id).filter(
    Turno.fecha_turno == hoy
    ).filter(Turno.zona == myuser.zona).all()   
    
        

    return render_template("vacunador/turnosausentes.html", turnos = turnos)

def registrarausentes():
    if not authenticated(session):
        abort(401)
    
    hoy = date.today()
    myuser = Usuario.query.filter(Usuario.email == session["user"]).first()
    
    turnos = Turno.query.join(Usuario).where(Turno.idpersona == Usuario.id).filter(
    Turno.fecha_turno == hoy
    ).filter(Turno.zona == myuser.zona).all()

    for turno in turnos:
        db.session.delete(turno)

    db.session.commit()
    flash('Ausentes a vacunación registrados')       

    return redirect(url_for("turnosdeldias"))

def newpersona():
    if not authenticated(session):
        abort(401)
    return render_template("vacunador/register.html")  

def validardni(dni):
    if dni > 3000000:
        if dni < 90000000: 
            return True
    return False 

def nuevapersona():
    if not authenticated(session):
        abort(401)
    params = request.form

    if params["dni"] == '1111111':
       flash("El DNI ingresado no es válido por RENAPER")
       return redirect(url_for("new_persona"))
   
    if not validardni(int(params["dni"])):
       flash("El DNI ingresado no es válido")
       return redirect(url_for("new_persona"))
    existdni = Usuario.query.filter(Usuario.dni == params["dni"]).first()
   
    if not existdni == None:
        flash('El DNI ingresado ya se encuentre registrado en el sistema')
        return redirect(url_for("new_persona"))
    
    existuser = Usuario.query.filter(Usuario.email == params["email"]).first()
   
    if not existuser == None:
        flash('El email ingresado ya se encuentre registrado en el sistema')
        return redirect(url_for("new_persona"))
 
    mipass = random.randint(100000,999999)
    codigo = random.randint(1000,9999)
   
    newuser = Usuario(params["nombre"],params["apellido"],params["dni"],params["fechanac"],params["telefono"],params["zona"],params["email"],mipass,codigo)
    return render_template("vacunador/registrarvacunas.html", newuser = newuser)  
  
def nuevapersonamisvacunas():
    if not authenticated(session):
        abort(401)
    params = request.form
    newuser = Usuario(params["nombre"],params["apellido"],params["dni"],params["fechanac"],params["telefono"],params["zona"],params["email"],params["password"],params["codigo"])
    
    if params["riesgo"] == "si":        
        newuser.riesgo = True

    else:
        newuser.riesgo = False

    newuser.log = True

    db.session.add(newuser)
    myuser = Usuario.query.filter(Usuario.email == newuser.email).first()
    
    if params["fiebre"] == "si":
        newfiebre = Misvacunas(params["email"],"Fiebre amarilla",params["fechafiebre"])
        newfiebre.idpersona = myuser.id
        
        db.session.add(newfiebre)
    
    if params["gripe"] == "si":
        newgripe = Misvacunas(params["email"],"Antigripal",params["fechagripe"])
        newgripe.idpersona = myuser.id
        
        db.session.add(newgripe)
    
    if params["covid"] == "si":
        newcovid = Misvacunas(params["email"],"Covid-19",params["fechacovid"])
        newcovid.idpersona = myuser.id
        
        db.session.add(newcovid)
    
    

    db.session.commit()

    flash(f'Su contraseña es: {newuser.password}. Su código 2fa es: {newuser.codigo}')

    return render_template("home.html")

def newvacunacion():
    if not authenticated(session):
        abort(401)
    return render_template("vacunador/newvacunacion.html") 

def confirmarvacunacion():
    if not authenticated(session):
        abort(401)
    params = request.form
    existdni = Usuario.query.filter(Usuario.dni == params["dni"]).first()
    
    if existdni == None:
        flash('El DNI ingresado no se encuentre registrado en el sistema')
        return redirect(url_for("new_vacunacion"))

    return render_template("vacunador/aceptarvacunacion.html", user = existdni, vacuna = params["vacuna"])

def aceptarvacunacion():
    if not authenticated(session):
        abort(401)
    
    params = request.form
    myuser = Usuario.query.filter(Usuario.dni == params["dni"]).first()
    vacunador = Usuario.query.filter(Usuario.email == session["user"]).first()
    hoy = date.today()
    
    #verifica que no tenga una vacuna igual, aplicada hoy mismo
    vacunas_aplicadas_hoy = Misvacunas.query.filter(Misvacunas.email == myuser.email ).filter(Misvacunas.fecha_aplicacion == hoy ).filter(Misvacunas.tipovacuna == params["vacuna"] ).first()  
    if not vacunas_aplicadas_hoy:

    
        newvacuna = Misvacunas(myuser.email,params["vacuna"],hoy)
        newvacuna.idpersona = myuser.id
        newvacuna.zona = vacunador.zona
        newvacuna.vacunador = vacunador.email

        db.session.add(newvacuna)
        db.session.commit()
        flash('La vacunación ha sido registrada exitosamente')

        return render_template("home.html")
    else:
        flash('La vacunación no se ha registrado porque ya se aplico hoy')
        return render_template("home.html")


