from flask import redirect, render_template, request, url_for, session, abort, flash
from sqlalchemy.sql.elements import Null
from app.models.user import User
from app.helpers.auth import authenticated
from app.db import db
from app.models.configModule import ConfigModule
from sqlalchemy import update
import bcrypt
from app.models.usuario import Usuario
from app.models.misvacunas import Misvacunas
from app.models.turno import Turno
from app.models.solicitud import Solicitud
from app.models.notificacion import Notificacion
from app.models.vacunatorio import Vacunatorio
import random
import datetime
from xmlrpc.client import DateTime

def cumpli18():
    if not authenticated(session):
        abort(401)
    myuser = Usuario.query.filter(Usuario.email == session['user']).first()
    myuser.fecnac = "1990-01-01"
    db.session.commit()
    flash("Ahora el usuario es mayor de edad")
    return redirect(url_for("home"))

def cumpli60():
    if not authenticated(session):
        abort(401)
    myuser = Usuario.query.filter(Usuario.email == session['user']).first()
    myuser.fecnac = "1940-01-01"
    db.session.commit()
    flash("Ahora el usuario es mayor de 60 años")
    return redirect(url_for("home"))

def vervacunadores():
    if not authenticated(session):
        abort(401)
           
    vacunadores = Usuario.query.filter(Usuario.rol == 'vacunador').all()
    
    return render_template("admin/vacunadores.html", vacunadores = vacunadores)

def vacunasaplicadas():
    if not authenticated(session):
        abort(401)
           
    vacunas = Misvacunas.query.join(Usuario).where(Misvacunas.idpersona == Usuario.id).all()  
    
    return render_template("admin/vacunasplaicadas.html", vacunas = vacunas)

def personasregistradas():
    if not authenticated(session):
        abort(401)
           
    personas = Usuario.query.filter(Usuario.rol == 'persona').all()  
    
    return render_template("admin/personasregistradas.html", personas = personas)

def solicitudespendientes():
    if not authenticated(session):
        abort(401)
           
    solicitudes = Solicitud.query.all() 

    for elem in solicitudes:
        myuser = Usuario.query.filter(Usuario.email == elem.email).first()
        ahora = datetime.datetime.utcnow()
        dias = ((ahora.date())-myuser.fecnac).days
        if dias > 21900: #verifica que sea mayor a 60
            if elem.tipovacuna == "Fiebre amarilla":
                newnoti = Notificacion(myuser.email,'Ha sido rechazada solicitud Fiebre amarilla por ser mayor a 60 años')
                db.session.add(newnoti)
                db.session.delete(elem)
                solicitudes.remove(elem)
        db.session.commit()     
    
    return render_template("admin/solicitudespendientes.html", solicitudes = solicitudes)


def darturno(solicitud_id):
    if not authenticated(session):
        abort(401)
    solicitud = Solicitud.query.filter(Solicitud.id == solicitud_id).first()
    
    myuser = Usuario.query.filter(Usuario.email == solicitud.email).first()
    ahora = datetime.datetime.utcnow()
    dias = ((ahora.date())-myuser.fecnac).days
    if dias > 21900: #verifica que sea mayor a 60

        if solicitud.tipovacuna == "Covid-19":
            fechag =  ahora + datetime.timedelta(days=7)
            fechag = fechag.date()
            hora = random.randint(8, 16)
            turnoc = Turno(myuser.email,"Covid-19",fechag,hora,myuser.zona)
            turnoc.idpersona = myuser.id
            db.session.add(turnoc)
            db.session.delete(solicitud)
            newnoti = Notificacion(myuser.email,'Ingrese a Mis turnos para ver su turno asignado Covid-19')
            db.session.add(newnoti)
            db.session.commit()
            flash("Se ha registrado un turno a 7 días por ser mayor de 60 años")

            return redirect(url_for("solicitudes_pendientes"))  
    
    
        
    return render_template("admin/darturno.html", myuser = myuser, vacuna = solicitud.tipovacuna, id_solicitud = solicitud_id)

def registrarturno():
    if not authenticated(session):
        abort(401)
    params = request.form

    solicitud = Solicitud.query.filter(Solicitud.id == params['id_solicitud']).first()
    
    myuser = Usuario.query.filter(Usuario.email == solicitud.email).first()

    turno = Turno(myuser.email, solicitud.tipovacuna, params['fechatur'], params['hora'], myuser.zona)
    turno.idpersona = myuser.id
    db.session.add(turno)
    db.session.delete(solicitud)
    url = '<a class="nav-link text-white" href="'+url_for('misturnos')+'" >Mis turnos</a>'
    desc = f'Ingrese a {url} para ver su turno asignado {solicitud.tipovacuna}'
    newnoti = Notificacion(myuser.email,desc)
    db.session.add(newnoti)
    db.session.commit()
    flash("Se ha registrado el turno exitosamente")

    return redirect(url_for("solicitudes_pendientes"))


def botones():
    if not authenticated(session):
        abort(401)
    return render_template("admin/botones.html")

def newvacunador():
    return render_template("admin/newvacunador.html")

def validardni(dni):
    if dni > 3000000:
        if dni < 90000000: 
            return True
    return False 

def createvacunador():
    params = request.form

    if params["dni"] == '11111111':
       flash("El DNI ingresado no es válido por RENAPER")
       return redirect(url_for("new_vacunador"))
   
    if not validardni(int(params["dni"])):
       flash("El DNI ingresado no es válido")
       return redirect(url_for("new_vacunador"))

    existdni = Usuario.query.filter(Usuario.dni == params["dni"]).first()
   
    if not existdni == None:
        flash('El DNI ingresado ya se encuentre registrado en el sistema')
        return redirect(url_for("new_vacunador"))

       
    existuser = Usuario.query.filter(Usuario.email == params["email"]).first()
   
    if not existuser == None:
        flash('El email ingresado ya se encuentre registrado en el sistema')
        return redirect(url_for("new_vacunador"))
 
    
    codigo = random.randint(1000,9999)
    mipass = random.randint(100000,999999)
   
    newuser = Usuario(params["nombre"],params["apellido"],params["dni"],params["fechanac"],params["telefono"],params["zona"],params["email"],mipass,codigo)
    newuser.rol = "vacunador"
    newuser.log = 1
    db.session.add(newuser)
    db.session.commit()
    flash(f"El vacunador ha sido creado exitosamente, la contraseña es: {mipass} y el codigo F2A es: {codigo}")    
    return redirect(url_for("home"))

def modificarnombrevacunatorio():
    if not authenticated(session):
        abort(401)
    vacunatorios = Vacunatorio.query.all()
    return render_template("admin/modificarvacunatorio.html", vacunatorios = vacunatorios)

def editarvacunatorio(vacu_id):
    if not authenticated(session):
        abort(401)
    
    vacunatorio = Vacunatorio.query.filter(Vacunatorio.id == vacu_id).first()
    return render_template("admin/editarvacunatorio.html", vacunatorio = vacunatorio)

def updatevacunatorio():
    if not authenticated(session):
        abort(401)
    params = request.form
    vacunatorio = Vacunatorio.query.filter(Vacunatorio.id == params['id']).first()
    vacunatorio.nombre = params['nombre']
    db.session.commit()
    flash('Nombre de vacunatorio modificado exitosamente')
    return redirect(url_for("modificar_nombre_vacunatorio"))

def searchpersonas():
    if not authenticated(session):
        abort(401)
    
    params = request.form
    
    if not params['dni'] == '':
        if not params['zona'] == '0':
            personas = Usuario.query.filter(Usuario.rol == 'persona').filter(Usuario.dni == params['dni']).filter(Usuario.zona == params['zona']).all()
            return render_template("admin/resultpersonas.html", personas = personas)
        else:
            personas = Usuario.query.filter(Usuario.rol == 'persona').filter(Usuario.dni == params['dni']).all()
            return render_template("admin/resultpersonas.html", personas = personas)
    else:
        if not params['zona'] == '0':
            personas = Usuario.query.filter(Usuario.rol == 'persona').filter(Usuario.zona == params['zona']).all()
            return render_template("admin/resultpersonas.html", personas = personas)
        else: 
            personas = Usuario.query.filter(Usuario.rol == 'persona').filter(Usuario.zona == params['zona']).all()
            flash('No se aplicó ningún filtro')
            return redirect(url_for("personas_registradas"))

def searchvacunas():
    if not authenticated(session):
        abort(401)
    
    params = request.form
    f1 = DateTime(params['fechadesde'])
    f2 = DateTime(params['fechahasta'])

    if not params['dni'] == '':
        if not params['vacuna'] == 'Indistinta':
            vacunas = Misvacunas.query.join(Usuario).where(Misvacunas.idpersona == Usuario.id).filter(Usuario.dni == params['dni']).filter(Misvacunas.tipovacuna == params['vacuna']).filter(Misvacunas.fecha_aplicacion.between(f1,f2)).all()
            
            return render_template("admin/resultvacunas.html", vacunas = vacunas, tipo = params['vacuna'])
        else:
            vacunas = Misvacunas.query.join(Usuario).where(Misvacunas.idpersona == Usuario.id).filter(Usuario.dni == params['dni']).filter(Misvacunas.fecha_aplicacion.between(f1,f2)).all()
            
            return render_template("admin/resultvacunas.html", vacunas = vacunas, tipo = params['vacuna'])
    else:
        if not params['vacuna'] == 'Indistinta':
            vacunas = Misvacunas.query.join(Usuario).where(Misvacunas.idpersona == Usuario.id).filter(Misvacunas.tipovacuna == params['vacuna']).filter(Misvacunas.fecha_aplicacion.between(f1,f2)).all()
            
            return render_template("admin/resultvacunas.html", vacunas = vacunas, tipo = params['vacuna'])
        else:
            vacunas = Misvacunas.query.join(Usuario).where(Misvacunas.idpersona == Usuario.id).filter(Misvacunas.fecha_aplicacion.between(f1,f2)).all()
            
            return render_template("admin/resultvacunas.html", vacunas = vacunas, tipo = params['vacuna'])

            
def searchvacunadores():
    if not authenticated(session):
        abort(401)
    
    params = request.form
    
    if not params['dni'] == '':
        if not params['zona'] == '0':
            vacunadores = Usuario.query.filter(Usuario.rol == 'vacunador').filter(Usuario.dni == params['dni']).filter(Usuario.zona == params['zona']).all()
            return render_template("admin/resultvacunadores.html", vacunadores = vacunadores)
        else:
            vacunadores = Usuario.query.filter(Usuario.rol == 'vacunador').filter(Usuario.dni == params['dni']).all()
            return render_template("admin/resultvacunadores.html", vacunadores = vacunadores)
    else:
        if not params['zona'] == '0':
            vacunadores = Usuario.query.filter(Usuario.rol == 'vacunador').filter(Usuario.zona == params['zona']).all()
            return render_template("admin/resultvacunadores.html", vacunadores = vacunadores)
        else: 
            vacunadores = Usuario.query.filter(Usuario.rol == 'vacunador').filter(Usuario.zona == params['zona']).all()
            flash('No se aplicó ningún filtro')
            return redirect(url_for("ver_vacunadores"))